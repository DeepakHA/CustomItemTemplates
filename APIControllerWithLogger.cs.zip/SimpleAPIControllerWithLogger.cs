﻿using Microsoft.AspNetCore.Mvc;

namespace $rootnamespace$
{
    [Route("api/[controller]")]
    [ApiController]
    public class $safeitemname$ : ControllerBase
    {
        private readonly ILogger _logger;
        public $safeitemname$(ILogger logger)
        {
            _logger = logger;
        }
    }
}
