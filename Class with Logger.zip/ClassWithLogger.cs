﻿using Microsoft.Extensions.Logging;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
        private readonly ILogger _logger;
        public $safeitemname$(ILogger logger)
        {
            _logger = logger;
        }
    }
}
