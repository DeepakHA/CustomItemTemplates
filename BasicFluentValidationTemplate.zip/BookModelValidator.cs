﻿using FluentValidation;

namespace $rootnamespace$
{
    public class $safeitemname$: AbstractValidator<$modelClassName$>
    {
        public $safeitemname$()
        {
            RuleFor(b => b.Id).NotEmpty().WithMessage("Id can't be empty");
        }
    }
}
